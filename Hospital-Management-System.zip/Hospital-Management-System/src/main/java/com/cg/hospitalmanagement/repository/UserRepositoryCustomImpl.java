package com.cg.hospitalmanagement.repository;

import com.cg.hospitalmanagement.model.User;

public class UserRepositoryCustomImpl implements UserRepositoryCustom {

	@Override
	public User findUser(String username, String password) {
		// TODO Auto-generated method stub
		return null;
	}

}


